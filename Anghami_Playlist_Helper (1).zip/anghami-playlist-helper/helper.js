(() => {
  'use strict';
  if (location.hostname !== 'play.anghami.com') return;
  const old = document.getElementById('anghami-playlist-helper');
  if (old) { old.style.display = 'block'; return; }
  const host = document.createElement('div'); host.id = 'anghami-playlist-helper';
  host.style.cssText = 'position:fixed;left:12px;bottom:90px;z-index:2147483647';
  const ui = host.attachShadow({mode: 'open'});
  ui.innerHTML = `<style>
  *{box-sizing:border-box}header{cursor:move;touch-action:none;display:flex;align-items:center;justify-content:space-between}header b{font-size:15px}section{background:white;color:#172334;font:14px/1.45 Arial;padding:17px;border:1px solid #aaa;border-radius:12px;width:350px;max-width:90vw;max-height:90vh;overflow:auto;box-shadow:0 8px 30px #0007}h2{margin:0 0 10px;font-size:18px}p{margin:9px 0}input{width:100%;padding:7px;margin:3px 0}button{border:0;background:#155eef;color:white;border-radius:6px;padding:8px;margin:3px 2px 3px 0;cursor:pointer}button:disabled{opacity:.4;cursor:default}#log{white-space:pre-wrap;max-height:140px;overflow:auto;background:#eef2f7;font-size:12px;padding:8px}small{display:block;color:#536174}#status{font-weight:bold}</style>
  <section><header id="drag"><b>Likes → Playlist · v1.1</b> <button id="toggle">Minimize</button></header><div id="body">
  <label>Destination playlist<input id="target" value="My Likes Backup"></label>
  <label>Exact Likes count, if known<input id="expected" type="number" min="1" placeholder="Optional; 2.1K is rounded"></label>
  <button id="detect">Check song detection</button><p>Open Likes at the top. Set up these controls once:</p>
  <button id="learn1">1. Learn song ⋮</button><button id="learn2" disabled>2. Learn Add to Playlist</button><button id="learn3" disabled>3. Learn playlist + Add</button>
  <p id="status">Click step 1 here, then click ⋮ on a song in your Likes list.</p>
  <p><button id="test" disabled>Test one song</button><button id="run" disabled>Run remaining Likes</button><button id="pause">Pause after current song</button><button id="report">Download report</button><button id="hide">Hide</button></p>
  <p id="counts">0 confirmed in playlist</p><div id="log"></div>
  <small>Uses the same Add controls as you. Never clicks Unlike, Delete or Create. No passwords, cookies or external requests in this extension. Progress lasts until page refresh. Already Added songs are checked again safely. Compare the final playlist and exact Likes counts; automatic scrolling cannot prove completeness. If paused, leave any open menu as it is and inspect it.</small></div></section>`;
  document.documentElement.append(host);
  const $ = id => ui.getElementById(id);
  function minimize(value) { $('body').hidden = value; $('toggle').textContent = value ? 'Expand' : 'Minimize'; }
  $('toggle').onclick = () => minimize(!$('body').hidden);
  $('drag').onpointerdown = e => {
    if (e.target.closest('button')) return;
    const rect = host.getBoundingClientRect(), dx = e.clientX - rect.left, dy = e.clientY - rect.top;
    $('drag').setPointerCapture(e.pointerId);
    $('drag').onpointermove = move => {
      host.style.bottom = 'auto'; host.style.right = 'auto';
      host.style.left = Math.max(0, Math.min(innerWidth - host.offsetWidth, move.clientX - dx)) + 'px';
      host.style.top = Math.max(0, Math.min(innerHeight - 45, move.clientY - dy)) + 'px';
    };
    $('drag').onpointerup = () => { $('drag').onpointermove = null; };
  };
  const clean = s => String(s || '').replace(/\s+/g, ' ').trim();
  const norm = s => clean(s).toLocaleLowerCase();
  const visible = e => e && e.isConnected && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden';
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let armed = 0, menuPath, menuTag, menuSignature, commandLabel, target, busy = false, stop = false, tested = false;
  const confirmed = new Map(), events = [];
  function status(s) { $('status').textContent = s; }
  function log(s) { events.push(s); $('log').textContent = events.slice(-8).join('\n'); }
  function counts() { $('counts').textContent = `${confirmed.size} distinct songs confirmed in playlist (Added).`; }
  function descendants(root) { return [...root.querySelectorAll('*')].filter(e => !host.contains(e) && visible(e)); }
  function labels(root, text) {
    return descendants(root).filter(e => norm(e.textContent) === norm(text) &&
      ![...e.children].some(c => visible(c) && norm(c.textContent) === norm(text)));
  }
  function only(items, what) { if (items.length !== 1) throw Error(`${what}: found ${items.length}; stopped to avoid guessing.`); return items[0]; }
  function signature(e) { return ['class','aria-label','title','role'].map(a => e.getAttribute(a) || '').concat(clean(e.textContent)).join('|'); }
  async function waitFor(fn, what, timeout = 10000) {
    const end = Date.now() + timeout;
    while (Date.now() < end) { const result = fn(); if (result) return result; await sleep(250); }
    throw Error(`Could not confirm ${what}. Check the open menu; no automatic retry.`);
  }
  const rowSelector = '.table-row,.table-row-no-style-link,a[itemtype="list"]';
  function rows() { return [...document.querySelectorAll(rowSelector)].filter(r => visible(r) && r.querySelector('.cell-title')); }
  $('detect').onclick = () => {
    const found = rows();
    status(found.length + ' song rows detected on the loaded page. This is not your total Likes count.');
    $('log').textContent = found.slice(0, 5).map(r => { const t = info(r); return t.title + ' — ' + t.artist; }).join('\n') || 'No rows found. Send a screenshot showing the song list and this message.';
  };
  function info(row) {
    const title = clean(row.querySelector('.cell-title')?.textContent);
    const artist = [...new Set([...row.querySelectorAll('a[href*="/artist"],.cell-artist,.cell-artists')].map(e => clean(e.textContent)).filter(Boolean))].join(', ');
    const album = clean(row.querySelector('a[href*="/album"],.cell-album')?.textContent);
    const id = row.getAttribute('data-track-id') || row.getAttribute('data-song-id') || row.querySelector('a[href*="/song/"]')?.getAttribute('href');
    return {key: id || [title, artist, album].join('\u0000'), title, artist, album};
  }
  function modal() {
    const inputs = [...document.querySelectorAll('input')].filter(e => visible(e) && /search.*playlist/i.test(e.placeholder || ''));
    if (inputs.length !== 1) return null;
    let e = inputs[0].parentElement;
    while (e && e !== document.body) {
      if (labels(e, 'Done').length || labels(e, 'Cancel').length) return e;
      e = e.parentElement;
    }
    return null;
  }
  function destination(root) {
    const names = labels(root, target);
    const choices = new Set();
    for (const name of names) {
      let e = name.parentElement;
      while (e && e !== root) {
        if (labels(e, '+ Add').length || labels(e, 'Added').length) { choices.add(e); break; }
        e = e.parentElement;
      }
    }
    return only([...choices], 'Exact destination playlist row');
  }
  function scrolling(row) {
    let e = row?.parentElement;
    while (e && e !== document.body) {
      const overflow = getComputedStyle(e).overflowY;
      if (e.clientHeight > 100 && e.scrollHeight > e.clientHeight + 8 && !['visible','clip'].includes(overflow)) return e;
      e = e.parentElement;
    }
    return document.scrollingElement;
  }
  document.addEventListener('click', e => {
    if (!armed || e.composedPath().includes(host)) return;
    minimize(false);
    try {
      if (armed === 1) {
        const row = e.target.closest(rowSelector);
        if (!row?.querySelector('.cell-title')) throw Error('Click the ⋮ inside a song row, not the player.');
        let node = e.target.closest('button,[role="button"]') || e.target;
        if (!row.contains(node) || node === row || node.closest('.cell-title')) throw Error('Select the song menu ⋮, not the song title.');
        if (node instanceof SVGElement) node = node.closest('svg').parentElement;
        const path = []; let cur = node;
        while (cur !== row) { path.unshift([...cur.parentElement.children].indexOf(cur)); cur = cur.parentElement; }
        menuPath = path; menuTag = node.tagName; menuSignature = signature(node);
        $('learn2').disabled = false; status('Song menu learned. Click step 2 here, then Add to Playlist in the song menu.');
      } else if (armed === 2) {
        let node = e.target;
        while (node && !/add.*playlist/i.test(clean(node.textContent))) node = node.parentElement;
        const label = clean(node?.textContent);
        if (!label || label.length > 100 || !/add.*playlist/i.test(label)) throw Error('Click the Add to Playlist menu item.');
        commandLabel = label; $('learn3').disabled = false;
        status('Click step 3 here, then + Add (or Added) beside your destination playlist.');
      } else {
        target = clean($('target').value);
        if (!target) throw Error('Enter the exact destination playlist name.');
        const root = modal(); if (!root) throw Error('Playlist selection window not recognized.');
        const dest = destination(root);
        if (!dest.contains(e.target) || !/^(\+\s*add|added)$/i.test(clean(e.target.textContent))) throw Error('Click + Add beside the exact named playlist.');
        $('target').disabled = true; $('test').disabled = false;
        status('Setup learned. Click Done in Anghami, return to the TOP of Likes, then Test one song.');
      }
      armed = 0;
    } catch (error) { armed = 0; status(error.message); }
  }, true);
  for (let n = 1; n <= 3; n++) $('learn' + n).onclick = () => {
    if (busy) return;
    armed = n; minimize(true);
    status(['', 'Now click ⋮ on a song in Likes.', 'Now click Add to Playlist in the song menu.', 'Now click + Add beside the exact destination playlist.'][n]);
  };
  async function copy(row) {
    if (modal()) throw Error('Close the playlist window with Done before starting.');
    const track = info(row);
    if (!track.title || !track.artist) throw Error('Song title or artist missing; stopped.');
    row.scrollIntoView({block: 'nearest'});
    // Mouse events reveal hover-only row menus; the saved child path avoids title/player clicks.
    row.dispatchEvent(new MouseEvent('mouseover', {bubbles: true}));
    await sleep(300);
    let trigger = row; for (const index of menuPath) trigger = trigger?.children[index];
    if (!trigger || trigger.tagName !== menuTag || signature(trigger) !== menuSignature || !visible(trigger)) throw Error('Learned song menu changed or is hidden. Set up again.');
    trigger.click();
    const command = await waitFor(() => {
      const found = labels(document, commandLabel); return found.length ? only(found, 'Add to Playlist command') : null;
    }, 'song menu');
    command.click();
    const root = await waitFor(modal, 'playlist selection window');
    const dest = destination(root);
    if (!labels(dest, 'Added').length) {
      const add = only(labels(dest, '+ Add'), 'Destination Add button');
      if (add.closest('button')?.disabled || add.getAttribute('aria-disabled') === 'true') throw Error('Add is disabled; stopped.');
      add.click();
      await waitFor(() => labels(destination(root), 'Added')[0], 'Added confirmation');
    }
    confirmed.set(track.key, {...track, result: 'Added confirmed'}); counts(); log(`Confirmed: ${track.title} — ${track.artist}`);
    only(labels(root, 'Done'), 'Done button').click();
    await waitFor(() => !visible(root), 'playlist window closing');
    await sleep(1200);
  }
  async function run(test) {
    if (busy) return;
    busy = true; stop = false; armed = 0;
    for (const id of ['learn1','learn2','learn3','test','run']) $(id).disabled = true;
    const route = location.href; let idle = 0;
    try {
      if (modal()) throw Error('Click Done in Anghami first. Then try again.');
      if (!rows().length) throw Error('No Likes rows recognized. Return to Likes.');
      while (!stop) {
        if (location.href !== route) throw Error('Page changed; stopped.');
        if (document.hidden) throw Error('Tab is hidden; return here and resume.');
        const available = rows();
        const row = available.find(r => !confirmed.has(info(r).key));
        if (row) {
          status('Adding and checking: ' + info(row).title);
          await copy(row); idle = 0;
          if (test) { tested = true; status('Test passed: Added confirmed. Check the destination playlist, return to Likes at the top, then Run remaining Likes.'); break; }
        } else {
          const scroller = scrolling(available[0]);
          if (!scroller) throw Error('Cannot find song list scrolling container.');
          const before = scroller.scrollTop;
          scroller.scrollTop += Math.max(100, scroller.clientHeight * .65);
          await sleep(2000);
          idle = scroller.scrollTop === before ? idle + 1 : 0;
          status('Looking for more songs… Compare final counts before transfer.');
          if (idle >= 10) {
            const expected = Number($('expected').value);
            status(`No new rows at the bottom for 20 seconds. ${expected ? (expected === confirmed.size ? 'Count matches your entered total.' : 'COUNT DOES NOT MATCH your entered total.') : 'Compare exact Likes and playlist counts.'} This is not a completeness guarantee.`); break;
          }
        }
      }
      if (stop) status('Paused after current song. Resume without refreshing; do not change pages.');
    } catch (error) { status(error.message); log('Stopped: ' + error.message); }
    finally {
      busy = false; $('test').disabled = false; $('run').disabled = !tested;
      for (let n = 1; n <= 3; n++) $('learn' + n).disabled = n > 1 && !(n === 2 ? menuPath : commandLabel);
    }
  }
  $('test').onclick = () => run(true); $('run').onclick = () => run(false);
  $('pause').onclick = () => { stop = true; armed = 0; status(busy ? 'Pausing after the current confirmation or timeout…' : 'Paused.'); };
  $('hide').onclick = () => { stop = true; armed = 0; host.style.display = 'none'; };
  $('report').onclick = () => {
    const cell = value => { let s = String(value || ''); if (/^[=+@\-\t\r]/.test(s)) s = "'" + s; return '"' + s.replace(/"/g, '""') + '"'; };
    const lines = [['Title','Artist','Album','Result'], ...[...confirmed.values()].map(t => [t.title,t.artist,t.album,t.result])];
    const csv = '\ufeff' + lines.map(r => r.map(cell).join(',')).join('\r\n');
    const a = document.createElement('a'), url = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8'}));
    a.href = url; a.download = 'Anghami_Playlist_Confirmed.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 30000);
  };
})();
