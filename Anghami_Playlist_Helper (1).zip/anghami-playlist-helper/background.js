chrome.action.onClicked.addListener(async tab => {
  try {
    const url = new URL(tab.url || '');
    if (url.protocol !== 'https:' || url.hostname !== 'play.anghami.com') return;
    await chrome.scripting.executeScript({target: {tabId: tab.id}, files: ['helper.js']});
  } catch (error) { console.error('Playlist helper:', error.message); }
});
