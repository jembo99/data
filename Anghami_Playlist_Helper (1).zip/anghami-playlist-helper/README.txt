MY ANGHAMI PLAYLIST HELPER - v1.1

This is a separate extension from the earlier CSV exporter.
It uses Anghami's page buttons to add songs to one existing playlist.
It does not remove Likes or create/delete playlists.
No external libraries, password/cookie access, or external requests in this code.

INSTALL
1. Extract the ZIP.
2. Chrome: chrome://extensions (Edge: edge://extensions).
3. Enable Developer mode, click Load unpacked.
4. Select the anghami-playlist-helper folder containing manifest.json.
5. Disable the old exporter to keep its panel out of the way.

SET UP (THREE PAGE CLICKS)
1. Open Anghami Web > Liked Songs. Close any playlist window with Done.
2. Click Extensions > My Anghami Playlist Helper.
3. Check the destination name. Default: My Likes Backup.
   Spaces are normalized; spelling must match. Use a unique playlist name.
4. In the helper click "1. Learn song ...". Then click the ... menu on
   a song row in the main Likes list, not the bottom player.
5. In the helper click "2. Learn Add to Playlist". Then click Anghami's
   Add to Playlist menu item. The playlist window should open.
6. In the helper click "3. Learn playlist + Add". Then click + Add beside
   My Likes Backup. This manually adds this setup song to that playlist.
   The helper must show "Setup learned"; otherwise stop and send its message.
7. Click Done in Anghami. Return to the TOP of Likes.

TEST AND RUN
1. Click Test one song. Wait for "Test passed: Added confirmed".
2. Check that song in the destination playlist yourself.
3. Return to Likes at the TOP, then click Run remaining Likes.
4. Keep the tab visible and do not use Anghami while it runs.
5. Pause after current song stops after the current check (or timeout).
   Hide also requests a pause. To reopen, click the extension again.
6. Download report to save the list confirmed in this session.

LIMITATIONS
This has not been tested on your live Anghami account. Page layouts vary.
It stops if a control cannot be recognized; send the status message and a
screenshot instead of repeating clicks. Success means the page displayed
Added, not an independent server audit. Final counts must be checked.
If Likes displays 2.1K, that is rounded; do not enter 2100 as an exact total
unless independently confirmed. Even equal counts do not prove exact matches.
Compare song contents too, and keep your original Likes until satisfied.
If no stable song ID is exposed, matching uses title + artist + album;
identically labelled versions may be counted together. The report is only
confirmed songs, not a complete inventory of failures or unvisited Likes.
Progress is kept only until refresh. After refresh redo setup; each song's
Added status is checked before an automatic Add click.
The helper recognizes English Add to Playlist, + Add, Added and Done.
If hover-only menus or page structure differ, it may stop before adding.
Do not use it on any page other than your Likes list.

Files: manifest.json, background.js, helper.js. All source is readable.

V1.1 CHANGES
Drag the header to move the panel; Minimize/Expand frees page controls.
Learning steps minimize the panel automatically until the next page click.
Check song detection previews loaded rows before setup; this is not the total.
Supports the table-row-no-style-link layout visible in your screenshot.
