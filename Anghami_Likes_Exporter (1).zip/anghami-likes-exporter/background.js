chrome.action.onClicked.addListener(async tab => {
  try {
    const u = new URL(tab.url || '');
    if (u.protocol !== 'https:' || u.hostname !== 'play.anghami.com') return;
    await chrome.scripting.executeScript({target: {tabId: tab.id}, files: ['exporter.js']});
  } catch (error) { console.error('Could not open exporter:', error.message); }
});
