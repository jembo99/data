(() => {
  'use strict';
  if (location.hostname !== 'play.anghami.com') return;
  const previous = document.getElementById('my-anghami-exporter');
  if (previous) { previous.style.display = 'block'; return; }
  const host = document.createElement('div'); host.id = 'my-anghami-exporter';
  host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647';
  const ui = host.attachShadow({mode: 'open'});
  ui.innerHTML = `<style>
  *{box-sizing:border-box}section{font:14px/1.5 Arial,sans-serif;background:#fff;color:#182334;width:390px;max-width:90vw;padding:20px;border:1px solid #ccc;border-radius:14px;box-shadow:0 8px 35px #0005}h2{font-size:19px;margin:0 0 8px}p{margin:9px 0}button{padding:9px 12px;border:0;border-radius:7px;background:#155eef;color:white;cursor:pointer;margin:4px 4px 4px 0}button:disabled{opacity:.45;cursor:default}input{width:100px;padding:6px}#status{font-weight:bold}#preview{max-height:170px;overflow:auto;font-size:12px;white-space:pre-wrap;background:#f3f5f8;padding:8px}small{display:block;color:#536174}</style>
  <section><h2>Anghami Likes → CSV · v1.1</h2><p>Open <b>Library → Liked Songs</b> first. This reads the current list, so avoid opening other pages while scanning.</p>
  <label>Your total Likes (optional): <input id="expected" type="number" min="1" step="1"></label>
  <p><button id="start">Start / Resume</button><button id="stop">Pause</button><button id="save" disabled>Download CSV</button><button id="close">Close</button></p>
  <p id="status">Ready. Start at the top of your Likes list.</p><div id="preview">Your song preview will appear here.</div>
  <small>Reads song titles, artists, albums and song links from the page. Saves a file on your computer. No password, cookies, API keys or external server. Keep this tab open until finished.</small></section>`;
  document.documentElement.appendChild(host);
  const $ = id => ui.getElementById(id);
  const tracks = new Map(); let started = false, running = false, timer, idle = 0, route = location.href;
  const clean = s => String(s || '').replace(/\s+/g, ' ').trim();
  const rowSelector = '.table-row';
  const artistSel = 'a[href*="/artist"],.cell-artist,.cell-artists,.artist-name,.track-artist';
  function readTracks() {
    // Anghami's Likes entries are a.table-row, with a non-link .cell-title.
    // Do not search for song links globally: that captures the bottom player.
    for (const row of document.querySelectorAll(rowSelector)) {
      const titleEl = row.querySelector('.cell-title');
      if (!titleEl || host.contains(row)) continue;
      const title = clean(titleEl.textContent);
      const artists = Array.from(row.querySelectorAll(artistSel), e => clean(e.textContent)).filter(Boolean);
      const artist = [...new Set(artists)].join(', ');
      if (!title || !artist) continue;
      const album = clean(row.querySelector('a[href*="/album"],.cell-album,.album-name')?.textContent);
      let url = '';
      const song = row.matches('a[href*="/song/"]') ? row : row.querySelector('a[href*="/song/"]');
      try { if (song) url = new URL(song.getAttribute('href'), location.origin).href; } catch {}
      const id = row.getAttribute('data-track-id') || row.getAttribute('data-song-id');
      const key = url || (id ? 'id:' + id : title + '\u0000' + artist + '\u0000' + album);
      tracks.set(key, {title, artist, album, url});
    }
  }
  function scrollables() {
    // Find the actual scrolling ancestors of the song table, including custom
    // containers whose scrolling is implemented without overflow:auto.
    const list = new Set();
    for (const row of document.querySelectorAll(rowSelector)) {
      let el = row.parentElement;
      while (el) {
        if (el.clientHeight >= 100 && el.scrollHeight > el.clientHeight + 8 &&
            getComputedStyle(el).overflowY !== 'visible' &&
            getComputedStyle(el).overflowY !== 'clip') list.add(el);
        el = el.parentElement;
      }
    }
    const page = document.scrollingElement;
    if (page && page.scrollHeight > page.clientHeight + 8) list.add(page);
    return [...list];
  }
  function render(message) {
    const expected = Number($('expected').value);
    $('status').textContent = `${tracks.size} songs captured. ${message}` + (expected ? ` Expected: ${expected}.` : ' Compare this count with Anghami.');
    $('preview').textContent = [...tracks.values()].slice(-8).map(x => `${x.title} — ${x.artist}`).join('\n') || 'No songs recognized yet. Pause and check that you are on Liked Songs. If necessary, send a screenshot for an updated parser.';
    $('save').disabled = tracks.size === 0;
  }
  function pause(message = 'Paused; you can scroll manually and resume.') {
    running = false; clearTimeout(timer); render(message);
  }
  function tick() {
    if (!running) return;
    if (location.href !== route) { pause('Page changed. Return to Likes and reload before exporting.'); return; }
    const before = tracks.size; readTracks();
    const els = scrollables();
    const atEnd = els.every(e => e.scrollTop + e.clientHeight >= e.scrollHeight - 8);
    idle = tracks.size === before && atEnd ? idle + 1 : 0;
    render('Scanning…');
    if (idle >= 10) { pause('No new songs at the end for 20 seconds. Verify the count before downloading; this does not prove the list is complete.'); return; }
    for (const el of els) el.scrollTop += Math.max(100, el.clientHeight * 0.65);
    timer = setTimeout(tick, 2000);
  }
  $('start').onclick = () => {
    if (running) return;
    if (!started) { for (const el of scrollables()) el.scrollTop = 0; started = true; }
    route = location.href; idle = 0; running = true; tick();
  };
  $('stop').onclick = () => pause();
  $('close').onclick = () => { pause(); host.style.display = 'none'; };
  $('expected').oninput = () => render(running ? 'Scanning…' : 'Ready to review.');
  $('save').onclick = () => {
    pause('Review the exported titles and count before importing into Spotify.');
    const expected = Number($('expected').value);
    if (expected && expected !== tracks.size && !confirm(`Captured ${tracks.size} songs, but expected ${expected}. Download an incomplete or mismatched list anyway?`)) return;
    const cell = value => {
      let s = String(value ?? '');
      if (/^[=+@\-\t\r]/.test(s)) s = "'" + s;
      return '"' + s.replace(/"/g, '""') + '"';
    };
    const data = [['Track name','Artist name','Album','Anghami URL'], ...[...tracks.values()].map(t => [t.title,t.artist,t.album,t.url])];
    const blob = new Blob(['\ufeff' + data.map(r => r.map(cell).join(',')).join('\r\n')], {type:'text/csv;charset=utf-8'});
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = 'Anghami_Liked_Songs.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 30000);
  };
})();
