(() => {
  'use strict';
  if (location.hostname !== 'play.anghami.com') return;
  const previous = document.getElementById('my-anghami-exporter');
  if (previous) { previous.style.display = 'block'; return; }
  const host = document.createElement('div'); host.id = 'my-anghami-exporter';
  host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647';
  const ui = host.attachShadow({mode: 'open'});
  ui.innerHTML = `<style>
  *{box-sizing:border-box}section{font:14px/1.5 Arial,sans-serif;background:#fff;color:#182334;width:390px;max-width:90vw;padding:20px;border:1px solid #ccc;border-radius:14px;box-shadow:0 8px 35px #0005}h2{font-size:19px;margin:0 0 8px}p{margin:9px 0}button{padding:9px 12px;border:0;border-radius:7px;background:#155eef;color:white;cursor:pointer;margin:4px 4px 4px 0}button:disabled{opacity:.45;cursor:default}input{width:100px;padding:6px}#status{font-weight:bold}#preview{max-height:170px;overflow:auto;font-size:12px;white-space:pre-wrap;background:#f3f5f8;padding:8px}small{display:block;color:#536174}</style>
  <section><h2>Anghami Likes → CSV</h2><p>Open <b>Library → Liked Songs</b> first. This reads the current list, so avoid opening other pages while scanning.</p>
  <label>Your total Likes (optional): <input id="expected" type="number" min="1" step="1"></label>
  <p><button id="start">Start / Resume</button><button id="stop">Pause</button><button id="save" disabled>Download CSV</button><button id="close">Close</button></p>
  <p id="status">Ready. Start at the top of your Likes list.</p><div id="preview">Your song preview will appear here.</div>
  <small>Reads song titles, artists, albums and song links from the page. Saves a file on your computer. No password, cookies, API keys or external server. Keep this tab open until finished.</small></section>`;
  document.documentElement.appendChild(host);
  const $ = id => ui.getElementById(id);
  const tracks = new Map(); let running = false, timer, idle = 0, route = location.href;
  const clean = s => String(s || '').replace(/\s+/g, ' ').trim();
  const songLink = 'a[href*="/song/"],a[href*="/song?"]';
  const artistSel = 'a[href*="/artist/"],.artist-name,.track-artist,.song-artist,[class*="artist-name"],[class*="artistName"]';
  function readTracks() {
    const rows = new Set(document.querySelectorAll('[data-track-id],[data-song-id],.track-row,.song-row,.track-item,.song-item'));
    for (const a of document.querySelectorAll(songLink)) {
      let row = a;
      for (let depth = 0; row.parentElement && depth < 7; depth++) {
        row = row.parentElement;
        const ids = new Set(Array.from(row.querySelectorAll(songLink), x => x.getAttribute('href')));
        if (ids.size > 1) break;
        if (row.querySelector(artistSel)) { rows.add(row); break; }
      }
    }
    for (const row of rows) {
      if (row.closest('footer,[role="contentinfo"],audio') || host.contains(row)) continue;
      const a = row.querySelector(songLink);
      const titleEl = a || row.querySelector('.track-title,.song-title,.cell-title,.title,[class*="trackTitle"],[class*="songTitle"]');
      const title = clean(titleEl?.textContent || titleEl?.getAttribute('title'));
      const artists = Array.from(row.querySelectorAll(artistSel), e => clean(e.textContent)).filter(Boolean);
      const artist = [...new Set(artists)].join(', ');
      // Never guess an artist from unrelated row text.
      if (!title || !artist) continue;
      let url = ''; try { if (a) url = new URL(a.getAttribute('href'), location.origin).href; } catch {}
      const id = row.getAttribute('data-track-id') || row.getAttribute('data-song-id');
      const key = url || (id ? 'id:' + id : title + '\u0000' + artist);
      const album = clean(row.querySelector('a[href*="/album/"],.album-name,.track-album')?.textContent);
      tracks.set(key, {title, artist, album, url});
    }
  }
  function scrollables() {
    const list = [document.scrollingElement];
    for (const el of document.querySelectorAll('main,div,section')) {
      if (el === host || el.clientHeight < 120 || el.scrollHeight <= el.clientHeight + 8) continue;
      if (/auto|scroll/.test(getComputedStyle(el).overflowY) && el.querySelector(songLink + ',[data-track-id],[data-song-id],.track-row,.song-row')) list.push(el);
    }
    return [...new Set(list)].filter(Boolean);
  }
  function render(message) {
    const expected = Number($('expected').value);
    $('status').textContent = `${tracks.size} songs captured. ${message}` + (expected ? ` Expected: ${expected}.` : ' Compare this count with Anghami.');
    $('preview').textContent = [...tracks.values()].slice(-8).map(x => `${x.title} — ${x.artist}`).join('\n') || 'No songs recognized yet. Pause and check that you are on Liked Songs. If necessary, send a screenshot for an updated parser.';
    $('save').disabled = tracks.size === 0;
  }
  function pause(message = 'Paused; you can scroll manually and resume.') {
    running = false; clearTimeout(timer); render(message);
  }
  function tick() {
    if (!running) return;
    if (location.href !== route) { pause('Page changed. Return to Likes and reload before exporting.'); return; }
    const before = tracks.size; readTracks();
    const els = scrollables();
    const atEnd = els.every(e => e.scrollTop + e.clientHeight >= e.scrollHeight - 8);
    idle = tracks.size === before && atEnd ? idle + 1 : 0;
    render('Scanning…');
    if (idle >= 10) { pause('No new songs at the end for 20 seconds. Verify the count before downloading; this does not prove the list is complete.'); return; }
    for (const el of els) el.scrollTop += Math.max(100, el.clientHeight * 0.65);
    timer = setTimeout(tick, 2000);
  }
  $('start').onclick = () => {
    if (running) return;
    route = location.href; idle = 0; running = true; tick();
  };
  $('stop').onclick = () => pause();
  $('close').onclick = () => { pause(); host.style.display = 'none'; };
  $('expected').oninput = () => render(running ? 'Scanning…' : 'Ready to review.');
  $('save').onclick = () => {
    pause('Review the exported titles and count before importing into Spotify.');
    const expected = Number($('expected').value);
    if (expected && expected !== tracks.size && !confirm(`Captured ${tracks.size} songs, but expected ${expected}. Download an incomplete or mismatched list anyway?`)) return;
    const cell = value => {
      let s = String(value ?? '');
      if (/^[=+@\-\t\r]/.test(s)) s = "'" + s;
      return '"' + s.replace(/"/g, '""') + '"';
    };
    const data = [['Track name','Artist name','Album','Anghami URL'], ...[...tracks.values()].map(t => [t.title,t.artist,t.album,t.url])];
    const blob = new Blob(['\ufeff' + data.map(r => r.map(cell).join(',')).join('\r\n')], {type:'text/csv;charset=utf-8'});
    const url = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = url; a.download = 'Anghami_Liked_Songs.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(url), 30000);
  };
})();
